extends Camera3D
@onready var sliding = $".."
var SLIDING = sliding.SLIDING
var mouse_sensitivity = 0.003
const min_pitch = deg_to_rad(-70) 
const max_pitch = deg_to_rad(80)
func _ready():
	Input.mouse_mode =Input.MOUSE_MODE_CAPTURED
func _unhandled_input(event:InputEvent):
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotation.x -= event.relative.y * mouse_sensitivity
		rotation.x = clamp(rotation.x, min_pitch, max_pitch)
func _input(event: InputEvent):
	if Input.is_action_just_pressed("ui_accept"):
		Input.mouse_mode =Input.MOUSE_MODE_CAPTURED
func _physics_process(delta: float):
	if Input.is_action_just_pressed("Shift") and SLIDING == false:
		rotation.x = -70
	
