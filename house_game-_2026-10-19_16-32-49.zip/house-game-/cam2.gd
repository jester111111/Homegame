extends Camera3D
func _input(event: InputEvent) -> void:
	if Input.is_action_just_pressed("ui_focus_next"):
		make_current()
